$(function(){
	function validateEmail(email) {
		var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		return re.test(email);
	}
  //$('.button-collapse').sideNav();
	$("#form").submit(function(e){    
		var $marca = $("#marca").val();
		var $modelo = $("#modelo").val();
		var $year = $("#year").val();
		var $email = $("#email").val();
		var mensajeError = "";
		var procesa = true; 
		if($marca === "0" || $modelo === "0" || $year === "0") {
			procesa = false;
			if($marca === "0"){
				mensajeError = "Selecciona la marca";
			} else if($modelo === "0") {
				mensajeError = "Selecciona el modelo";
			} else {
				mensajeError = "Selecciona el año";
			}
		}
		if(procesa) {
			if(!validateEmail($email)) {
				mensajeError = "El email no es válido";
				$("#email").focus();
				procesa = false;
			}
		}
		if(!procesa) {
			swal("Error!", mensajeError, "error");
			event.preventDefault(); 
		}
	});	
});