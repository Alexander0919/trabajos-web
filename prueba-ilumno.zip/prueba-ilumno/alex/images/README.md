Iconos se pueden encontrar en la pagina: http://fontawesome.io/icons/#web-application

- fa-chevron-down
- fa-facebook
- fa-twitter
- fa-google-plus
- fa-quote-left